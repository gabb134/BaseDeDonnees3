﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Labo5
{
    public partial class frmListeDeValeurs : Form
    {
        public frmListeDeValeurs()
        {
            InitializeComponent();
        }
    }
}
