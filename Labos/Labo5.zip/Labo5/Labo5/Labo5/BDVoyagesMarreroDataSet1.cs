﻿namespace Labo5
{
}

namespace Labo5
{


    public partial class BDVoyagesMarreroDataSet
    {
    }
}
namespace Labo5 {
    
    
    public partial class BDVoyagesMarreroDataSet {
    }
}
