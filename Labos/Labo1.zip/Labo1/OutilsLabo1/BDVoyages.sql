-- ===========================================================================
-- cette base de donn�es est tir�e du document D�veloppeur 2000 Forms 5.0 de Jean-Yves Papillon
-- fichier : DBVoyages.sql				
--  projet : Agence de voyage Tototour
-- ==-----------------------------------------------------------------------==
--  
--==-----------------------------------------------------------------------==
--   Script de cr�ation de la base de donn�es de l'agence de voyage
--   table cr��es :
--    client, employe, hotel, voyage, contrat, faitLeVoyage
--
-- ==-----------------------------------------------------------------------==


-- remplacer BDVoyages par le nom de votre base de donn�es
use BDVoyagesMarrero  

Print  'Cr�ation de la base de donn�es de l''agence de voyage Tototour.'
print  'Derni�re modification, 16 ao�t 2019.'
print ''
Print  'destruction des tables...'
DROP TABLE faitLeVoyage;
DROP TABLE contrat;
DROP TABLE voyage;
DROP TABLE hotel;
DROP TABLE employe;
DROP TABLE client;


print 'Cr�ation des tables ========================================================'
print ''
Print  'Cr�ation de la TABLE client...' 
CREATE TABLE client (
   cliNo		NUMERIC(6) ,
   cliPrenom		VARCHAR(20),
   cliNom		VARCHAR(15),
   cliRue		VARCHAR(30),
   cliVille		VARCHAR(12) DEFAULT 'Totoville',
   cliTelephone	CHAR(12),
   CONSTRAINT pk_client  PRIMARY KEY(cliNo)
   );

print 'Cr�ation de la TABLE employe...'
CREATE TABLE employe (
  empNo			NUMERIC(4),
  empPrenom		VARCHAR(20),
  empNom		VARCHAR(15),
  empEmploi		CHAR(2),   
  empSal		NUMERIC(5,2),
  empComm		NUMERIC(3,3),
  empSup		NUMERIC(4),
  empBureau		CHAR(3),    
 CONSTRAINT pk_employe PRIMARY KEY(empNo),
 CONSTRAINT check_empEmploi CHECK  (empEmploi IN('DI', 'GR', 'VD', 'SC', 'AN')),
 CONSTRAINT check_empBureau CHECK (empBureau IN ('stf', 'l�v', 'bpt'))
  );

Print  'Cr�ation de la TABLE hotel...'
CREATE TABLE hotel (
  hotNo			NUMERIC(5),  
  hotNom		CHAR(25),
  hotCote		NUMERIC(1), 
  hotPiscine		CHAR(1),   
  hotNbChambreTot 	NUMERIC(3),
  CONSTRAINT pk_hotel PRIMARY KEY(hotNo),
  CONSTRAINT check_hotCote CHECK (hotCote BETWEEN 1 AND 5),
  CONSTRAINT check_hotPiscine CHECK (hotPiscine IN ('A','E','I')),
  );

Print  'Cr�ation de la TABLE voyage...'
CREATE TABLE voyage (
  voyNo				NUMERIC(4),  
  voyDestination 		CHAR(20),
  voyDateDepart			DATETIME,
  voyDateArrive			DATETIME,
  voyRepas			NUMERIC(1),
  voyNbPlace        		NUMERIC(3),
  voyActivite 			CHAR(76),
  empNo             		NUMERIC(4), 
  hotno				NUMERIC(5),
  tarifSimple			NUMERIC(6,2),
  tarifDouble			NUMERIC(6,2),
  tarifTriple			NUMERIC(6,2),
  tarifQuadruple    		NUMERIC(6,2),
  NbChambreRes      		NUMERIC(3),
  CONSTRAINT pk_voyage PRIMARY KEY(voyNo),
  CONSTRAINT check_voyRepas CHECK (voyRepas IN(0,1,2)),
  CONSTRAINT fk_animateur FOREIGN KEY(empNo) references employe(empNo),
  CONSTRAINT fk_inclus FOREIGN KEY(hotno) references  hotel(hotNo)
);

Print  'Cr�ation de la TABLE contrat...'
CREATE TABLE contrat (
 conNo			NUMERIC(6),    
 conDate        	DATETIME,
 conAcompte     	NUMERIC(6,2),
 conMontant     	NUMERIC(6,2),
 ConPaye       		NUMERIC(6,2) DEFAULT 0,
 conTypeOcc     	NUMERIC(1), 
 empNo			NUMERIC(4),
 voyNo 			NUMERIC(4),
 cliNo 			NUMERIC(6)
 CONSTRAINT pk_contrat PRIMARY KEY(conNo),
 CONSTRAINT check_contypeoc CHECK (conTypeOcc IN (1,2,3,4)),
 CONSTRAINT fk_vendeur FOREIGN KEY( empNo)  REFERENCES employe(empNo),
 CONSTRAINT fk_choixVoyage FOREIGN KEY(voyNo) REFERENCES voyage(voyNo),
 CONSTRAINT fk_clientPayeur FOREIGN KEY(cliNo) REFERENCES client(cliNo)
);


print  'Cr�ation de la TABLE faitleVoyage...'
CREATE TABLE faitLeVoyage(
  conNo   NUMERIC(6),
  cliNo   NUMERIC(6),
  CONSTRAINT pk_faitLeVoyage PRIMARY KEY(conNo, cliNo),
  CONSTRAINT fk_faitVoyageContrat FOREIGN KEY(conNo) REFERENCES contrat(conNo),
  CONSTRAINT fk_faitVoyageClient FOREIGN KEY(cliNo) REFERENCES client(cliNo)
 );



                                                                                  
	select * from employe
	select * from contrat

	--b 
	select conNo,conDate,empNom from contrat c
	inner join employe e on e.empNo = c.empNo
	--c
		select c.empNo,empNom,count(c.empNo) from contrat c
	inner join employe e on e.empNo = c.empNo
	group by c.empNo,empNom

	-- d 1.
	select * from voyage
	select * from hotel


	select 'Nombre d''h�tels � Montr�al: '+convert(varchar,count(hotNom)) from hotel 
	where hotNom like '%Montr�al%'

	--d 2.
	--update hotel set hotNom = 


	--e
	--	select voyNo, voyDateDepart,voyDateArrive,voyDestination from voyage where voyDestination = 'Montr�al'

	--F
	

	begin transaction
	go
	select * from voyage where voyDestination = 'Montr�al'

	--update voyage set tarifSimple = tarifTriple * 1.10 where voyDestination = 'Montr�al'
		
	select tarifSimple from voyage where voyDestination = 'Montr�al'


	rollback 
	go


	--G.
	select * from employe
	select * from contrat
	select * from voyage 



	select empNo,sum(conMontant) from contrat group by empNo


	--H 


	select hotNom,h.hotno from hotel h inner join voyage v on h.hotNo = v.hotno where v.voyNo like '3002'

	-- I. 
	SELECT * from faitLeVoyage

	begin transaction
	--insert into faitLeVoyage values(444014,123024)
	--delete from faitLeVoyage where conNo = 444014 and cliNo = 123024
	rollback

	--J 



	--k

	select empNo,empPrenom,empNom from employe