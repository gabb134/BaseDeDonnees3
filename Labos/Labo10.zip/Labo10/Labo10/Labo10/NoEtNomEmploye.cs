﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo10
{
    class NoEtNomEmploye
    {
      public decimal noEmploye { get; private set; }
      public string nomCompletEmploye { get; private set; }
     
    }
}
