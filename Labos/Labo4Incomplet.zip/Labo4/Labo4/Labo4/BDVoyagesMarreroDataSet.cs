﻿namespace Labo4
{
}

namespace Labo4
{


    public partial class BDVoyagesMarreroDataSet
    {
    }
}
namespace Labo4 {
    
    
    public partial class BDVoyagesMarreroDataSet {
    }
}
