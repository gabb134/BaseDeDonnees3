﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Labo4
{
    public partial class frmReservationVoyages : Form
    {
        //Le numéro du client qui va effectuer des réservations
        public String noClient;
        public frmReservationVoyages()
        {
            InitializeComponent();
        }

        private void voyageBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.voyageBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.bDVoyagesMarreroDataSet);

        }

        private void voyageBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            this.Validate();
            this.voyageBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.bDVoyagesMarreroDataSet);

        }

        private void frmReservationVoyages_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'bDVoyagesMarreroDataSet.infosVoyages'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.infosVoyagesTableAdapter.Fill(this.bDVoyagesMarreroDataSet.infosVoyages);
            // TODO: cette ligne de code charge les données dans la table 'bDVoyagesMarreroDataSet.destinationsVoyages'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.destinationsVoyagesTableAdapter.Fill(this.bDVoyagesMarreroDataSet.destinationsVoyages);
            // TODO: cette ligne de code charge les données dans la table 'bDVoyagesMarreroDataSet.destinationsVoyages'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.destinationsVoyagesTableAdapter.Fill(this.bDVoyagesMarreroDataSet.destinationsVoyages);
            // TODO: cette ligne de code charge les données dans la table 'bDVoyagesMarreroDataSet.voyage'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.voyageTableAdapter.Fill(this.bDVoyagesMarreroDataSet.voyage);

        }
    }
}
