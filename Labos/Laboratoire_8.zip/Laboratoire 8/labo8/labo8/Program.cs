﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labo8
{
    class Program
    {
        private static List<Produit> lstProduits = new List<Produit>();
        private static List<Client> lstClients = new List<Client>();

        static void Main(string[] args)
        {
            // Remplissage des produits
            lstProduits.Add(new Produit(1, 10));
            lstProduits.Add(new Produit(2, 20));
            lstProduits.Add(new Produit(3, 30));
            lstProduits.Add(new Produit(4, 40));
            lstProduits.Add(new Produit(5, 50));
            lstProduits.Add(new Produit(6, 60));

            // Remplissage des clients
            Client unClient = new Client("Joseph", "Montréal", "Canada");
            unClient.ajouteCommande(new Commande(1, 3, false, Mois.Janvier, 1));
            unClient.ajouteCommande(new Commande(2, 5, true, Mois.Mai, 2));
            lstClients.Add(unClient);

            unClient = new Client("John", "Winnipeg", "Canada");
            unClient.ajouteCommande(new Commande(3, 10, false, Mois.Juillet, 1));
            unClient.ajouteCommande(new Commande(4, 20, true, Mois.Decembre, 3));
            lstClients.Add(unClient);

            unClient = new Client("James", "Dallas", "USA");
            unClient.ajouteCommande(new Commande(5, 20, true, Mois.Decembre, 3));
            lstClients.Add(unClient);

            unClient = new Client("Frank", "Seatle", "USA");
            unClient.ajouteCommande(new Commande(6, 20, false, Mois.Juillet, 5));
            lstClients.Add(unClient);
        }
    }
}
    

